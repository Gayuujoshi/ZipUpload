package com.spcl.GangaVilas.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Luxurybooking {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	Integer id;
	
	
	
	
	String name;
	String email;
	String phone;
    String pass;
    String destination;
    String travelmode;
    String traveldate;
    String comment;
    String rememberme;
    String license;
   
    
	public Luxurybooking() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Luxurybooking(Integer id, String name, String email, String phone, String pass, String destination,
			String travelmode, String traveldate, String comment, String rememberme, String license) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.phone = phone;
		this.pass = pass;
		this.destination = destination;
		this.travelmode = travelmode;
		this.traveldate = traveldate;
		this.comment = comment;
		this.rememberme = rememberme;
		this.license = license;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getPass() {
		return pass;
	}


	public void setPass(String pass) {
		this.pass = pass;
	}


	public String getDestination() {
		return destination;
	}


	public void setDestination(String destination) {
		this.destination = destination;
	}


	public String getTravelmode() {
		return travelmode;
	}


	public void setTravelmode(String travelmode) {
		this.travelmode = travelmode;
	}


	public String getTraveldate() {
		return traveldate;
	}


	public void setTraveldate(String traveldate) {
		this.traveldate = traveldate;
	}


	public String getComment() {
		return comment;
	}


	public void setComment(String comment) {
		this.comment = comment;
	}


	public String getRememberme() {
		return rememberme;
	}


	public void setRememberme(String rememberme) {
		this.rememberme = rememberme;
	}


	public String getLicense() {
		return license;
	}


	public void setLicense(String license) {
		this.license = license;
	}


	@Override
	public String toString() {
		return "Luxurybooking [id=" + id + ", name=" + name + ", email=" + email + ", phone=" + phone + ", pass=" + pass
				+ ", destination=" + destination + ", travelmode=" + travelmode + ", traveldate=" + traveldate
				+ ", comment=" + comment + ", rememberme=" + rememberme + ", license=" + license + "]";
	}
    
    
    
    
}
