
package com.spcl.GangaVilas.Controller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spcl.GangaVilas.Model.BasicPackage;
import com.spcl.GangaVilas.Model.Career;
import com.spcl.GangaVilas.Model.Contact;
import com.spcl.GangaVilas.Model.Login;
import com.spcl.GangaVilas.Model.Luxurybooking;
import com.spcl.GangaVilas.Model.Standardbooking;


@Controller
public class GangaController {
	
	@Autowired
	SessionFactory sf;
	
	
	@RequestMapping("/")
	public String Tologin() {
		return "login";
	}
	
	
	
	
	
	@RequestMapping("/login")
	public String Toset(@ModelAttribute Login l1, Model model) {
		
		
	Session ss=sf.openSession();
	
	Login dblogin=ss.get(Login.class, l1.getUsername());
	l1.getUsername().equals(l1.getUsername());
	String page="login";
	String msg = null;
	
	if(dblogin !=null) {
		if(l1.getPassword().equals(l1.getPassword())) {
			page="home";
		}else {
			msg="invalid password";
		}
	}else {
		msg="invalid Username";
	}
	model.addAttribute("msg",msg);
	return page;
	}
	
	
	
	
	
	
	@RequestMapping("/contactPage")
	public String Tocontact() {
		return "contact";
	}
	
	@RequestMapping("contact")
	public Contact Tocontactt(@ModelAttribute Contact c1) {
		Session ss =sf.openSession();
		Transaction tx=ss.beginTransaction();
		
		
	     
		
	      ss.save(c1);
	      tx.commit();
	      return c1;
	}
	
	
	
	
	
	
	
	
	
	
	@RequestMapping("/insert")
	public String Toadmininsert() {
		return "contact";
	}
	
	
	
	
	@PostMapping("/contact")
	public Contact ToinsertContact(@ModelAttribute Contact c63) {
		Session ss =sf.openSession();
		Transaction tx=ss.beginTransaction();
		
		ss.save(c63);
		tx.commit();
		return c63;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	@RequestMapping("/loginPage")
	public String Toback() {
		return "login";
	}
	
	
	
	
	@RequestMapping("/luxPage")
	public String Tolux() {
		return "luxury";
	}
	
	
	@RequestMapping("luxury")
	public Luxurybooking Toluxbook(@ModelAttribute Luxurybooking l45) {
		Session ss =sf.openSession();
		Transaction tx=ss.beginTransaction();
		
		ss.save(l45);
		tx.commit();
		return l45;
	}
	
	
	
	@RequestMapping("/stanpage")
	public String Tostandard() {
		return "standard";
	}
	
	@RequestMapping("standard")
	public Standardbooking Tostandardbooking(@ModelAttribute Standardbooking s1) {
        Session ss=sf.openSession();
       Transaction  tx=ss.beginTransaction();
       
       ss.save(s1);
       tx.commit();
       return s1;
	}
	
	
	@RequestMapping("/basicpage")
	public String Tobasic() {
		return "basicpackage";
	}
	
	
	@PostMapping("/basicpackage")
	public BasicPackage toBasic(@ModelAttribute BasicPackage b1) {
		 Session ss=sf.openSession();
	     Transaction  tx=ss.beginTransaction();
	     
	     ss.save(b1);
	     tx.commit();
	     return b1;
		
	}
	
	
	
	
	
	
	
	
	@RequestMapping("/servicePage")
	public String toservice() {
		return "service";
	}
	
	@RequestMapping("/careerPage")
	public String Tocareer() {
		return "career";
	}
	
	@PostMapping("/career")
	public Career Tocar(@ModelAttribute Career c1) {
		 Session ss=sf.openSession();
	     Transaction  tx=ss.beginTransaction();
	       
	       ss.save(c1);
	       tx.commit();
	       System.out.println(c1);
	       return c1;
	}
	
	
	@RequestMapping("/adminbasic")
	public String toadminbas() {
		return "adminbasicpackage";
	}
	
}
