package com.spcl.GangaVilas.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Contact {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int id;
	
	
	
	String firstname;
	String lastname;
	String mobi;
	String subject;
	public Contact() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Contact(int id, String firstname, String lastname, String mobi, String subject) {
		super();
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.mobi = mobi;
		this.subject = subject;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getMobi() {
		return mobi;
	}
	public void setMobi(String mobi) {
		this.mobi = mobi;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	@Override
	public String toString() {
		return "Contact [id=" + id + ", firstname=" + firstname + ", lastname=" + lastname + ", mobi=" + mobi
				+ ", subject=" + subject + "]";
	}
	
	
	

}
