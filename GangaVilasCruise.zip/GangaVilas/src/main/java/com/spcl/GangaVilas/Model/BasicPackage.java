package com.spcl.GangaVilas.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class BasicPackage {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	
	Integer id;
	String Name;
	String Email;
	int AreaCode;
	int Number;
	double MobileNumber;
	String datepicker2;
	String PickupAddress;
	String DestinationAddress;
	String journey;
	public BasicPackage() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BasicPackage(Integer id, String name, String email, int areaCode, int number, double mobileNumber,
			String datepicker2, String pickupAddress, String destinationAddress, String journey) {
		super();
		this.id = id;
		Name = name;
		Email = email;
		AreaCode = areaCode;
		Number = number;
		MobileNumber = mobileNumber;
		this.datepicker2 = datepicker2;
		PickupAddress = pickupAddress;
		DestinationAddress = destinationAddress;
		this.journey = journey;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public int getAreaCode() {
		return AreaCode;
	}
	public void setAreaCode(int areaCode) {
		AreaCode = areaCode;
	}
	public int getNumber() {
		return Number;
	}
	public void setNumber(int number) {
		Number = number;
	}
	public double getMobileNumber() {
		return MobileNumber;
	}
	public void setMobileNumber(double mobileNumber) {
		MobileNumber = mobileNumber;
	}
	public String getDatepicker2() {
		return datepicker2;
	}
	public void setDatepicker2(String datepicker2) {
		this.datepicker2 = datepicker2;
	}
	public String getPickupAddress() {
		return PickupAddress;
	}
	public void setPickupAddress(String pickupAddress) {
		PickupAddress = pickupAddress;
	}
	public String getDestinationAddress() {
		return DestinationAddress;
	}
	public void setDestinationAddress(String destinationAddress) {
		DestinationAddress = destinationAddress;
	}
	public String getJourney() {
		return journey;
	}
	public void setJourney(String journey) {
		this.journey = journey;
	}
	@Override
	public String toString() {
		return "BasicPackage [id=" + id + ", Name=" + Name + ", Email=" + Email + ", AreaCode=" + AreaCode + ", Number="
				+ Number + ", MobileNumber=" + MobileNumber + ", datepicker2=" + datepicker2 + ", PickupAddress="
				+ PickupAddress + ", DestinationAddress=" + DestinationAddress + ", journey=" + journey + "]";
	}
	
	
   
}
