package com.spcl.GangaVilas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GangaVilasApplication {

	public static void main(String[] args) {
		SpringApplication.run(GangaVilasApplication.class, args);
		System.err.println("GangaVilas");
		
	}

}
