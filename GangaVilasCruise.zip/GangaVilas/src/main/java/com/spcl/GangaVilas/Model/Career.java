package com.spcl.GangaVilas.Model;


import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.type.ImageType;

@Entity
public class Career {
	
	@Id
	String firstname;
	ImageType filee;
	public Career() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Career(String firstname, ImageType filee) {
		super();
		this.firstname = firstname;
		this.filee = filee;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public ImageType getFilee() {
		return filee;
	}
	public void setFilee(ImageType filee) {
		this.filee = filee;
	}
	@Override
	public String toString() {
		return "Career [firstname=" + firstname + ", filee=" + filee + "]";
	}
	
	
	

}
