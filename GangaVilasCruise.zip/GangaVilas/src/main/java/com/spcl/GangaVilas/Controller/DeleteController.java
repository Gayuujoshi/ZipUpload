package com.spcl.GangaVilas.Controller;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spcl.GangaVilas.Model.BasicPackage;
import com.spcl.GangaVilas.Model.Contact;
import com.spcl.GangaVilas.Model.Luxurybooking;
import com.spcl.GangaVilas.Model.Standardbooking;

@Controller
public class DeleteController {
	
	@Autowired
	SessionFactory sf;
 
	@RequestMapping("/pat/{id}")
	public String Todelppppppp(@PathVariable int id) {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		Contact c1=ss.load(Contact.class, id);
		ss.delete(c1);
		tx.commit();
        return "redirect:/adminContactPage";	
		
	}
	 
	@RequestMapping("/rat/{id}")
	public String Toluxdel(@PathVariable int id) {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		Luxurybooking b1=ss.load(Luxurybooking.class, id);
		ss.delete(b1);
		tx.commit();
		return "redirect:/adminLuxPage";
		
	}

	@RequestMapping("/delst/{id}")
	public String toDelstan(@PathVariable int id) {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		Standardbooking s1=ss.load(Standardbooking.class, id);
		ss.delete(s1);
		tx.commit();
		return "redirect:/adminstandard";
	}
	
	
	 
	@RequestMapping("/dellete/{id}")
	public String todelbasic(@PathVariable int id) {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		BasicPackage b1=ss.load(BasicPackage.class, id);
		ss.delete(b1);
		tx.commit();
		return "redirect:/adminbasic";
	}
}
