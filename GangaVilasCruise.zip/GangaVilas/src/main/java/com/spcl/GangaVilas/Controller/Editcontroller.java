package com.spcl.GangaVilas.Controller;


import org.hibernate.Session;
import org.hibernate.SessionFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.spcl.GangaVilas.Model.Contact;

@Controller
public class Editcontroller {
	@Autowired
	SessionFactory sf;
	
	
	@RequestMapping("/edit/{id}")
	public ModelAndView edit(@PathVariable int id) {
		ModelAndView mv= new ModelAndView();
		Session ss=sf.openSession();
		Contact c1=ss.load(Contact.class, id);
		mv.addObject("c1",c1);
		mv.setViewName("consee");
		return mv;
	}
	
	@RequestMapping("/contactupdate")
	public String editt(Contact c) {
		Session ss=sf.openSession();
		ss.saveOrUpdate(c);
		return "home";
	}
}
