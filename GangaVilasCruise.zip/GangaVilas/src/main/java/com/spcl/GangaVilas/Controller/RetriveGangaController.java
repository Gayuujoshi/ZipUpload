package com.spcl.GangaVilas.Controller;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.spcl.GangaVilas.Model.Adminlogin;
import com.spcl.GangaVilas.Model.BasicPackage;
import com.spcl.GangaVilas.Model.Contact;
import com.spcl.GangaVilas.Model.Login;
import com.spcl.GangaVilas.Model.Luxurybooking;
import com.spcl.GangaVilas.Model.Standardbooking;

@Controller
public class RetriveGangaController {

	
	@Autowired
	SessionFactory sf;
	
	
	

	@RequestMapping("/adminPage")
	public String Tosettt(@ModelAttribute Adminlogin  l1, Model model) {	
    Session ss=sf.openSession();
	
    Adminlogin dblogin=ss.get(Adminlogin.class, l1.getUsername());
	l1.getUsername().equals(l1.getUsername());
	String page="login";
	String msg = null;
	
	
	if(dblogin !=null) {
		if(l1.getPassword().equals(l1.getPassword())) {
			page="adminhome";
		}else {
			msg="invalid password";
		}
	}else {
		msg="invalid Username";
	}
	model.addAttribute("msg",msg);
	return page;
	}
	
	
	
	
	
	
	
	
	
	
	
	@RequestMapping("/sopan/{id}")
	public String Todelppppppp(@PathVariable int id) {
		System.err.println("yes "+ id);
		return "home";
	}
	
	
	@RequestMapping("/adminContactPage")
	public ModelAndView Toasd() {
		
		Session ss=sf.openSession();
		
		Criteria cr1=ss.createCriteria(Contact.class);
		List<Contact> k89=cr1.list();
		
		
		ModelAndView view =new ModelAndView();
		view.addObject("k89" ,k89);
		view.setViewName("showcontact");
		return view;
		
	}
	
	@GetMapping("/adminLuxPage")
       public ModelAndView Toretluxbooking() {
		Session ss=sf.openSession();
		
		Criteria cr1=ss.createCriteria(Luxurybooking.class);
		List<Luxurybooking> k41=cr1.list();
		
		
		ModelAndView view=new ModelAndView();
		view.addObject( "k41",k41);
		view.setViewName("showluxurybooking");
		return view;
						
	}
	
	@GetMapping("/adminstandard")
	public ModelAndView Tostandardbooking() {
		Session ss=sf.openSession();
		
		Criteria cr2=ss.createCriteria(Standardbooking.class);
		List<Standardbooking> k42=cr2.list();
		
		ModelAndView view=new ModelAndView();
		view.addObject("k42",k42);
		System.out.println(k42);
		view.setViewName("showstandardbooking");
		return view;
	}
	
	
	@GetMapping("/adminbasic")
	public ModelAndView Toad() {
		Session ss=sf.openSession();
		Criteria cr3=ss.createCriteria(BasicPackage.class);
		List<BasicPackage> k25=cr3.list();
	
		ModelAndView view=new ModelAndView();
		view.addObject("k25",k25);
		view.setViewName("adminbasicpackage");
		return view;
		
	}
	
	
	
	
	
	
	
	
	
}
