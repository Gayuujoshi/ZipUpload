package com.spcl.GangaVilas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GangaVilasApplicationTests {

	@Test
	void contextLoads() {
	}

}
